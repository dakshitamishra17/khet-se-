const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
    name: { type: String, required: true },
    farmer: { type: String, required: true }, // For now, storing name, can be ref to User later
    farmerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    loc: { type: String, required: true },
    cat: { type: String, required: true },
    emoji: { type: String, default: '🌾' },
    price: { type: Number, required: true },
    mandiPrice: { type: Number },
    unit: { type: String, default: 'kg' },
    fresh: { type: Boolean, default: true },
    organic: { type: Boolean, default: false },
    bg: { type: String, default: '#f5fff5' },
    qty: { type: Number, required: true },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Product', ProductSchema);
