const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    orderId: { type: String, required: true },
    date: { type: Date, default: Date.now },
    items: [
        {
            name: { type: String },
            qty: { type: Number },
            price: { type: Number },
            emoji: { type: String }
        }
    ],
    total: { type: Number, required: true },
    status: { type: String, enum: ['processing', 'transit', 'delivered'], default: 'processing' },
    payment: { type: String, enum: ['cod', 'upi'], default: 'cod' }
});

module.exports = mongoose.model('Order', OrderSchema);
