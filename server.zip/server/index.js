const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();

// --- MIDDLEWARE ---
app.use(cors());
app.use(express.json());

// --- ROUTES ---
app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/orders', require('./routes/orders'));

// --- BASIC ROUTES ---
app.get('/', (req, res) => {
    res.json({ msg: 'KhetSe API is running...', status: 'OK' });
});

app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        database: mongoose.connection.readyState === 1 ? 'Connected' : 'Disconnected',
        timestamp: new Date()
    });
});

// --- DATABASE CONNECTION ---
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/khetse';

mongoose.connect(MONGO_URI)
    .then(() => console.log('✅ MongoDB Connected successfully!'))
    .catch(err => {
        console.error('❌ MongoDB Connection Error:');
        console.error(err.message);
        console.log('💡 Tip: Make sure your local MongoDB service is running or check your MONGO_URI in .env');
    });

// --- START SERVER ---
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`📡 Auth endpoints: http://localhost:${PORT}/api/auth`);
    console.log(`📦 Product endpoints: http://localhost:${PORT}/api/products`);
});
