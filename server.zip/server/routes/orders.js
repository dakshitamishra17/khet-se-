const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const auth = require('../middleware/auth');

// @route   GET api/orders
// @desc    Get user orders
router.get('/', auth, async (req, res) => {
    try {
        const orders = await Order.find({ userId: req.user.id }).sort({ date: -1 });
        res.json(orders);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

// @route   POST api/orders
// @desc    Place an order
router.post('/', auth, async (req, res) => {
    const { items, total, payment } = req.body;

    try {
        const newOrder = new Order({
            userId: req.user.id,
            orderId: 'KS' + Date.now().toString().slice(-5),
            items,
            total,
            payment
        });

        const order = await newOrder.save();
        res.json(order);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

module.exports = router;
