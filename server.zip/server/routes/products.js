const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const auth = require('../middleware/auth');

// @route   GET api/products
// @desc    Get all products
router.get('/', async (req, res) => {
    try {
        const products = await Product.find().sort({ createdAt: -1 });
        res.json(products);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

// @route   POST api/products
// @desc    Add a new product (Farmer only)
router.post('/', auth, async (req, res) => {
    if (req.user.role !== 'farmer') {
        return res.status(403).json({ msg: 'Authorization denied, only farmers can list products' });
    }

    const { name, cat, price, mandiPrice, unit, emoji, organic, loc, qty, farmer } = req.body;

    try {
        const newProduct = new Product({
            name, cat, price, mandiPrice, unit, emoji, organic, loc, qty, farmer,
            farmerId: req.user.id
        });

        const product = await newProduct.save();
        res.json(product);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

module.exports = router;
