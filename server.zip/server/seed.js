const mongoose = require('mongoose');
require('dotenv').config();
const Product = require('./models/Product');

const demoData = [
    { 
        name: 'Fresh Tomatoes', 
        farmer: 'Ramesh Patel', 
        loc: 'Berasia, Bhopal', 
        cat: 'vegetables', 
        emoji: '🍅', 
        price: 32, 
        mandiPrice: 45, 
        unit: 'kg', 
        organic: true, 
        qty: 50 
    },
    { 
        name: 'Sharbati Wheat', 
        farmer: 'Suresh Kumar', 
        loc: 'Sehore Road', 
        cat: 'grains', 
        emoji: '🌾', 
        price: 30, 
        mandiPrice: 42, 
        unit: 'kg', 
        organic: false, 
        qty: 10 
    },
    { 
        name: 'Organic Palak', 
        farmer: 'Ankit Meena', 
        loc: 'Ratibad, Bhopal', 
        cat: 'vegetables', 
        emoji: '🥬', 
        price: 28, 
        mandiPrice: 40, 
        unit: 'bundle', 
        organic: true, 
        qty: 30 
    },
    { 
        name: 'Desi Ghee', 
        farmer: 'Aarti Devi', 
        loc: 'Misrod, Bhopal', 
        cat: 'dairy', 
        emoji: '🧈', 
        price: 480, 
        mandiPrice: 600, 
        unit: 'kg', 
        organic: true, 
        qty: 20 
    }
];

mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/khetse')
    .then(async () => {
        console.log('📡 Connected to MongoDB for seeding...');
        await Product.deleteMany({});
        await Product.insertMany(demoData);
        console.log('🌱 Database Seeded with Bhopal Farmers!');
        process.exit();
    })
    .catch(err => {
        console.error('❌ Seeding Error:', err.message);
        process.exit(1);
    });
